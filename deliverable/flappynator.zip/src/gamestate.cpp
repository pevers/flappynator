#include "gamestate.h"

GameState::GameState()
{
    this->currentState = ST_STARTING;
}

GameState::~GameState()
{
    //dtor
}

