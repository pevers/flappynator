# flappynator
Flappy equiped with a Bazooka.

# build
sudo apt-get install libsoil-dev libglm-dev libglew-dev libsfml-dev
